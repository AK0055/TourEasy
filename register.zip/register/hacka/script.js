fetch("https://covid-19-data.p.rapidapi.com/country?name=italy", {
	"method": "GET",
	"headers": {
		"x-rapidapi-key": "1b79a65a27msh8abeb909a4262ecp145783jsn49bb1e416dc8",
		"x-rapidapi-host": "covid-19-data.p.rapidapi.com"
	}
})
.then(response => {
	console.log(response);
})
.catch(err => {
	console.error(err);
});